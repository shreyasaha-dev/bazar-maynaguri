import React from "react";
import "./footer.css";

const Footer = () => {
  const categories = [
    "Vegetable",
    "Fruits",
    "Daily Products",
    "Organic Products",
    "Grocery Items",
  ];
  return (
    <footer className="footer">
      <div className="footer-top-section">
        <div className="footer-left-section">
          <img
            src={require("../../images/logo1.png")}
            alt="Logo"
            className="logo"
          />
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris
            egestas sem tellus, ac consectetur mi gravida nunc sit amet ante
            vitae ante facilisis
          </p>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris
            egestas sem tellus, ac consectetur mi
          </p>
          <a href="" className="read-more">
            Read more{" "}
            <img src={require("../../images/side arrow.png")} alt="arrow" />
          </a>
        </div>
        <div className="footer-right-section">
          <div className="footer-right-top">
            <div className="quick-links">
              <h3>Quick Links</h3>
              <div className="quick-link-left">
                <ul>
                  <li>
                    <a href="#home">Home</a>
                  </li>
                  <li>
                    <a href="#about">About Bazer Maynaguri</a>
                  </li>
                  <li>
                    <a href="#contact">Contact Us</a>
                  </li>
                  <li>
                    <a href="#faq">FAQ</a>
                  </li>
                </ul>
              </div>
              <div className="quick-link-right">
                <ul>
                  <li>
                    <a href="#enquiry">Enquiry Us</a>
                  </li>
                  <li>
                    <a href="#b2b">B2B Information</a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="footer-section contact-us">
              <h3>Contact Us</h3>
              <p>Sarkar shoss exclusive</p>
              <p>
                Natun Bazar turminal complex, PO: Maynaguri, Dist: Jalpaiguri,
                Pin: 753224.
              </p>
              <p>Phone: +91 7797813261</p>
              <p>
                Email:{" "}
                <a href="mailto:dhrubadjs.mng@gmail.com">
                  dhrubadjs.mng@gmail.com
                </a>
              </p>
            </div>
          </div>
          <div className="footer-right-bottom">
            <p>Popular Categories</p>
            <div className="categories">
              {categories.map((item) => {
                return <p className="each-category">{item}</p>;
              })}
            </div>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© Copyright 2020 bazermaynaguri.com | All Rights Reserved.</p>
        <div className="socials">
          <h3>Follow us on : </h3>
          <a href="http://twitter.com">
            <img src={require("../../images/twitter.png")} alt="twitter" />
          </a>
          <a href="http://facebook.com">
            <img src={require("../../images/facebook.png")} alt="facebook" />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
