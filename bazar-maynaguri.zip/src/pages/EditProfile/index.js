import React from "react";

const EditProfile = () => {
  return <div>EditProfile</div>;
};

export default EditProfile;
