import React from "react";
import { useDispatch } from "react-redux";
import { addToken } from "../../store/Reducers/userDataReducer";

const Home = () => {
  const dispatch = useDispatch();
  return (
    <div>
      Home
      <button
        onClick={() => {
          dispatch(addToken(""));
        }}
      >
        log out
      </button>
    </div>
  );
};

export default Home;
